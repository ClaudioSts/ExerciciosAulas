import logo from './logo.svg';
import './App.css';
import TwoLists from './TwoLists';

function App() {
  return (
    <div className="App">
      < TwoLists />
    </div>
  );
}

export default App;
