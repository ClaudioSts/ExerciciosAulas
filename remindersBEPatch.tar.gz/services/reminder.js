const { insertReminder, updateReminder } = require("../data/reminder")

async function lembranca(description, remindAt) {
    const resultado = await insertReminder({
        description: description,
        remindAt: remindAt
    })
    return resultado
}



module.exports = {
    lembranca,
}