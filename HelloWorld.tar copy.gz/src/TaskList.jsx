import styles from "./styles/TaskList.module.css"
/*
TODO

[x] - Criar uma lista a partir do array(tasks)

[x] - Para mapear arrays, é preciso recorrer ao .map
[x] - A função de mapeamento recebe como primeiro argumento o elemento do array
[x] - Cada elemento do array passa a ser um <li>
[x] - O conteúdo de cada <li> deve ser o proprio elemento do array (task)
[x] - Adicionar uma prop `key` única aos elementos mapeados




[x] - Criar um state para guardar a própria lista(array)

[x] - Cada item deve incluir uma Checkbox
[x] - A checkbox deve alterar o estado de conclusão do seu item
    [x] - Saber o indice do elemento que foi selecionado
    [x] - alterar o estado
[x] - Deve ser possível guardar o estado de conclusão de uma tarefa

[x] - apresenta os itens concluídos como rasurados
    [x] - indentificar que itens estao concluidos
    [x] - saber como rasurar 
    
[x] - Todos os itens não concluidos devem ser editáveis
    [x] - indentificar que itens estao concluidos
    [x] - Criação do modo de edição
        [x] - Clicar no texto para ativar
        [x] - Clicar noutro sitio para desativar

[x] - Ao pressionar Enter, sair do modo de edição
    [x] - identificar quando o Enter é pressionado
    [x] - alterar a propriedade editing

TASKS -> TASK[]

TASK -> {
    content: string,
    done: boolean,
    editing: boolean
}
*/

import { useState } from "react"

export function TaskList({ tasks }) {
    const [state, setState] = useState(tasks.map(task => ({ content: task, done: false, editing: false })))

    const handleChecked = (index, checked) => {
        setState((prevState) => {
            return prevState.map((task, i) => i === index ? ({ ...task, done: checked }) : task)
        })
    }
    const handleEdit = (index) => {
        setState((prevState) => {
            return prevState.map((task, i) => i === index && !task.done ? ({ ...task, editing: !task.editing }) : ({ ...task, editing: false }))
        })
    }
    const handleChange = (text, index) => {
        setState((prevState) => {
            return prevState.map((task, i) => i === index && !task.done ? ({ ...task, content: text }) : task)
        })
    }
    const disableEditing = () => {
        setState((prevState) => {
            return prevState.map((task, i) => ({ ...task, editing: false }))
        })
    }
    const addElement = () => {
        setState((prevState) => {
            return prevState.map(t => ({ ...t, editing: false })).concat({ content: "a", done: false, editing: true })
        })
    }
    const deleteElement = (index) => {
        setState((prevState) => prevState.slice(0, index).concat(prevState.slice(index + 1)))
    }
    // console.log(state.map(t => t.content))
    return (
        <div
            onClick={() => disableEditing()}
        >
            <ul>
                {
                    state.map((task, i) => (
                        <div key={`${i}`}>
                            <li>
                                {
                                    task.editing ?
                                        <div onClick={(e) => { e.stopPropagation(); e.nativeEvent.stopImmediatePropagation() }}>
                                            <input
                                                onKeyDown={(e) => e.key === "Enter" ? handleEdit(i) : null}
                                                autoFocus
                                                value={task.content}
                                                onChange={e => handleChange(e.target.value, i)}
                                                type={"text"}
                                            />
                                            <button onClick={() => deleteElement(i)}>X</button>
                                        </div>
                                        :
                                        <div onClick={(e) => { e.stopPropagation(); e.nativeEvent.stopImmediatePropagation() }}>
                                            <input onChange={(e) => handleChecked(i, e.target.checked)} checked={task.done} type={"checkbox"} />
                                            <span onClick={() => handleEdit(i)} className={task.done ? styles.done : ""}>{task.content}</span>
                                        </div>
                                }
                            </li>
                        </div>
                    ))
                }
            </ul>
            <button onClick={(e) => { addElement(); { e.stopPropagation(); e.nativeEvent.stopImmediatePropagation() } }}>CLICA</button>
        </div>
    )
}