// import { useState } from "react"
// import styles from './Sudoku.module.css'


// function Sudoku() {
//     const [matriz, setMatriz] = useState(new Array(9).fill(" ").map(linha => new Array(9).fill("#FFFFFF")))
//     const [corSelecionada, setSelecionada] = useState("#ff0054")

//     const mudaCor = (linha, coluna) => {
//         setMatriz((prevMatriz) => {
//                 return prevMatriz.map((line, i) => {
//                     return line.map((casa, j) => {
//                         if(i === linha && j === coluna){
//                             return corSelecionada
//                         }
//                         return casa
//                     })
//                 })
//         })
//     }

//     return (
//         <div>
//             {
//                 matriz.map((linha, i) => (
//                     <div className={styles.row} key={`${i}`}>
//                         {
//                             linha.map((casa, j)=> (
//                                 <div
//                                 style={{backgroundColor: casa}} 
//                                 onClick={() => mudaCor(i, j)}
//                                 className={styles.cell} 
//                                 key={`${i}${j}`}>
//                                 </div>
//                             ))
//                         }
//                     </div>

//                 ))
//             }
//         </div>
//     )
// }


// export default Sudoku

