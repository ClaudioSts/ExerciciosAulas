import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import Contador from './ReactContador';
import GeradorNumeros from './GeradorNumeros';
import GeradorNomes from './GeradorNomes';
import ListaComApagar from './ListaComApagar';
import Sudoku from './Sudoku';
import {Notificacao} from './FeedNotificacoes';
import HelloWorld from './HelloWorld';

function App() {
  const [state, setState] = useState(false)
  return (
    <div className="App">
      < HelloWorld/>
    </div>
  );

}

export default App;
