import { useState } from "react"

function ListaComApagar(props) {

    const [itens, setItens] = useState(props.itens);

    const removerItem = (indexToDelete) => {
        setItens((prevItens) => prevItens.filter((item, index) => index !== indexToDelete)
        );
    };

    return (
        <div >
            {itens.map((item, i) => (
                <div key={item.key}>
                    <h3>{item.name}</h3>
                    <p>{`${item.price} €`}</p>
                    <button onClick={() => removerItem(i)}>Remover</button>
                </div>)
            )
            }
        </div>

    )
}


export default ListaComApagar