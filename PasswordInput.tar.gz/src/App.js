import logo from './logo.svg';
import './App.css';

import Checkbox from "./Checkbox"
import PasswordInput from './PasswordInput';
function App() {
  return (
    <div className="App">
      < PasswordInput />
    </div>
  );
}

export default App;
