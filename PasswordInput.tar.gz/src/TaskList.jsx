import { useState } from "react";
import { TaskCount, TaskCountAlt } from "./TaskCount";
import { TaskItem } from "./TaskItem";

export function TaskList({tasks, setTasks}){
    const[mostrar, setMostrar] = useState(true)
    return(
        <div>
            <ul>
                {
                    tasks
                        .filter(t => mostrar || !t.concluido)
                        .map((t, i) => (
                            <TaskItem
                                key={i}
                                concluido={t.concluido}
                                texto={t.texto}
                                removeTarefa={() =>
                                }
                                alteraTexto={(novoTexto) =>
                                    setTasks(ts => 
                                        ts.map((ti, iti) => i === iti
                                            ? ({...ti, texto: novoTexto})
                                            :ti
                                            ))
                                }
                                alternaConcluido={() => 
                                    setTasks(ts => 
                                        ts.map((ti, iti) => i === iti
                                            ? ({...ti, concluido: !ti.concluido})
                                            :ti
                                            ))}
                                />
                    ))
                }
            </ul>
            <button onClick={() => setMostrar}>
                {!mostrar ? 'Mostrar' : 'Esconder'}
            </button>
            <TaskCount tasks={tasks}/>
            <TaskCountAlt 
                doneCount={task.concluido}
            />
        </div>
    )
}