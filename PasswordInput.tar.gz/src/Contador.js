import { useState } from "react"

function Contador(){
    //const array = useState(0)
    const [contador, setContador] = useState(0)
    //array[0]
    //array[1]
    const decrementar = () => {
        setContador((prevContador) => prevContador - 1)
    }
    
    const incrementar = () => {
        setContador((prevContador) => prevContador + 1)

    }
    
    
    return(
        <div role="main">
            <button onClick={decrementar} disabled={contador <= 0}>-</button>
            <p>{contador}</p>
            <button onClick={incrementar}>+</button>
        </div>
    )
}

export default Contador


/*
function incrementa()
    {
        let value = parseInt(document.getElementById('valor').value);
        value = isNaN(value) ? 0 : value;
        value++;
        document.getElementById('valor').value = value;
    }
function decrementa()
    {
        let value = parseInt(document.getElementById('valor').value);
        value = isNaN(value) ? 0 : value;
        value--;
        document.getElementById('valor').value = value;
    }



}



*/