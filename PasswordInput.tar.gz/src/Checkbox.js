import { useState } from "react"

function Checkbox({initialState}){
    const [bol, setBol] = useState(initialState)
    const mudarEstado = () =>{
        setBol((prevBol) => !prevBol)
    }

    return(
        <div>
            <button onClick={() => mudarEstado()}>{bol ? "Ativo" : "Inativo"}</button>
        </div>
    )
}

export default Checkbox