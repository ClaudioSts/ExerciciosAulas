const express = require("express")
const { findAllReminders, getReminderByID, updateReminder, deleteReminder } = require("./data/reminder")
const { lembranca, nvReminder } = require("./services/reminder")
const app = express()
const PORT = process.env.PORT ?? 4000
app.use(express.json())


app.get("/api/reminders", async (req, res) => {
    const history = await findAllReminders()
    res.status(200).json(history)
})

app.post("/api/reminders", async (req, res) => {
    const { description, remindAt } = req.body
    const id = await lembranca(description, remindAt)
    res.status(201).json({ _id: id })
})

app.get("/api/reminders/:id", async (req, res) => {
    const reminderId = req.params.id
    const reminder = await getReminderByID(reminderId)

    //if(!ObjectId.isValid(req.params.id)) {return res.sendStatus(404)}
    if (reminder && reminderId == reminder._id) {
        res.status(200).json( reminder )
    } else
        res.sendStatus(404)
})

app.patch("/api/reminders/:id", async (req, res) => {
    const { description, remindAt } = req.body
    const reminderId = req.params.id
    const reminder = await getReminderByID(reminderId)

    //if(!ObjectId.isValid(req.params.id)) {return res.sendStatus(404)}
    if (reminder && reminderId == reminder._id) {
        const newReminder = await updateReminder(reminderId, description, remindAt)
        res.sendStatus(200)
    } else
        res.sendStatus(404)
})

app.delete("/api/reminders/:id", async (req, res) => {
    const { description, remindAt } = req.body
    const reminderId = req.params.id
    const reminder = await getReminderByID(reminderId)

    //if(!ObjectId.isValid(req.params.id)) {return res.sendStatus(404)}
    if (reminder && reminderId == reminder._id) {
        const newReminder = await deleteReminder(reminderId, description, remindAt)
        res.sendStatus(200)
    } else
        res.sendStatus(404)
})

app.listen(PORT, () => console.log("..."))