export function TaskItem ({concluido, texto}) {

    if (concluido) {
        return <li><s>{texto}</s></li>
    } else {
        return <li>{texto}</li>
    }

    return (
        <div>

        </div>
    )
}

export function TaskList ({tasks}) {

    return <ul>
        {
            tasks.map((t, i) => (
                <TaskItem
                    key={t.texto}
                    concluido={t.concluido}
                    texto={t.texto}
                    alternaConcluido= {() =>
                        setTasks(ts =>
                            ts.map(ti => ti.texto === t.texto
                                ? ({...ti, concluido : !ti.concluido}))
                                )}/>)
            )
                            }               
                            
            </ul>
}