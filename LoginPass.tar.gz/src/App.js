import logo from './logo.svg';
import './App.css';
import { useState, useEffect } from 'react';
import Contador from './ReactContador';
import GeradorNumeros from './GeradorNumeros';
import GeradorNomes from './GeradorNomes';
import ListaComApagar from './ListaComApagar';
import Sudoku from './Sudoku';
import {Notificacao} from './FeedNotificacoes';
import HelloWorld from './HelloWorld';
import Login from './Login';

const credentials = [
  {username: "maria", password: "QWERTY123"},
  {username: "pauloc21", password: "pAsSwOrD1992"},
  {username: "gustavo", password: "q#$FSAss209%"},
  {username: "tania", password: "tanita.98"}
]


function App() {
  const [state, setState] = useState(false)
  return (
    <div className="App">
      < Login info={credentials}/>
    </div>
  );

}

export default App;
