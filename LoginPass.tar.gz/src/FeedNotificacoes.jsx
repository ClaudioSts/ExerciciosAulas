// import { useState } from "react"

// export function Notificacao (props) {

//     const [state, setState] = useState(props.map(props => ({ content: "", source: "", color: "" })))


//     return (
//         <div>
//             <ul>
//                 {
//                     state.map((props, i) => (
//                         <div key={`${i}`}>
//                             <li>
//                                 {
//                                    <Notificacao content= "Não percas já o lorem do ..." source= "Pinteres" color= "#ff0054" /> 
//                                 }
//                             </li>
//                         </div>
//                     ))  
//                 }
//             </ul>
//         </div>
//     )
// }

// function FeedDeNotificacoes (props) {

//     const [state, setState] = useState(props.notificacoes (notificacoes => [{source: "string", content: "string", color: "string"}]))

//     const checkNotif = () => {
//         setState((prevState) => {
//             return prevState.map((notificacoes) => notificacoes.length == 0 ? ("Não há notificações disponiveis") : notificacoes)
//         })
//     }
// }


import React from "react";

const Notification = (props) => {

const [width, setWidth] = useState(0);
const [intervalID, setIntervalID] = useState(null);

const handleStartTimer = () => {
    const id = setInterval(() => {
        setWidth( (prev) => {
            if (prev < 100) {
                return prev + 0.5
            }
            return prev
        })
    }, 20);
    setIntervalID(id)
};

const handlePauseTimer = () => {
    clearInterval(intervalID)
};

React.useEffect( () => {
    handleStartTimer() 
}, []);


    return (

        <div onMouseEnter={handlePauseTimer} onMouseLeave={handleStartTimer} className={`notification-item ${props.type === "SUCCESS" ? "success" : "error"}`}>
            <p>{props.message}</p>
            <div className={"bar"} style={{width: `${width}%`}}>

            </div>
        </div>
    )
}


export default Notification