import { useState } from "react"

function GeradorNomes() {

    const [randomN, setRandomN] = useState("Clique em Gerar.")

    const names = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n"]
    const adje = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    const gerarNome = () => {
        const aleatorio = `${names[Math.floor(Math.random()* names.length)]} + ${adje[Math.floor(Math.random()* adje.length)]}`
        setRandomN(aleatorio)
    }
    return (
        <div>
            <h1>Gerador de Nomes</h1>
            <p>{randomN}</p>
            <button onClick={() => gerarNome()}>Gerar</button>
        </div>
    )
}

export default GeradorNomes