import { useState } from "react";

export default function Login(props) {
  let [credentials, setCredentials] = useState({ username: "", password: "" });
  let [isLoggedIn, setLoggedIn] = useState(false);

  const authenticate = (e) => {
    e.preventDefault();
    // if (credentials.username === props.info.username) {
    //   if (credentials.password === props.info.password) {
    //   } else {
    //     return <p>Não</p>;
    //   }
    // }
    console.log(
      props.info.some(
        (cre) =>
          cre.username === credentials.username &&
          cre.password === credentials.password
      )
    );
    setLoggedIn(
      props.info.some(
        (cre) =>
          cre.username === credentials.username &&
          cre.password === credentials.password
      )
    );
  };

  const changeCredentials = (property, value) => {
    setCredentials((oldCred) => ({
      ...oldCred,
      [property]: value,
    }));
  };

  return (
    <div>
      <form onSubmit={authenticate}>
        <label>
          Username:{" "}
          <input
            value={credentials.username}
            onChange={(e) => changeCredentials("username", e.target.value)}
            type="text"
          />
        </label>
        <label>
          Password:{" "}
          <input
            value={credentials.password}
            onChange={(e) => changeCredentials("password", e.target.value)}
            type="text"
          />
        </label>
        <button type="submit">Login</button>
      </form>
      {isLoggedIn && <p>Bem vindo(a), {credentials.username}!</p>}
    </div>
  );
}
