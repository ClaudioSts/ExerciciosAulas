import React from "react";
import {v4} from "uuid";

const NotificationProvider = () => {
    const notifications = [
        {
            id: v4(),
            type: "SUCCESS",
            message: "Hello!"
        },
        {
            id: v4(),
            type: "ERROR",
            message: "Goodbye!"
        }
    ];

    return (
        <div>
            <div className={"notification-wrapper"}>
                {notifications.map(note => {
                    return <Notification key={note.id} {...note}/>
                })}
            </div>
            {props.children}
        </div>
    )
}

export default NotificationProvider