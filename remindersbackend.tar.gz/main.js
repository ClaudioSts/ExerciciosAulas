const express = require("express")
const { findAllReminders, getReminderByID, updateReminder } = require("./data/reminder")
const { lembranca, nvReminder } = require("./services/reminder")
const app = express()
const PORT = process.env.PORT ?? 4000
app.use(express.json())


app.get("/api/reminders", async (req, res) => {
    const history = await findAllReminders()
    res.status(200).json(history)
})

app.post("/api/reminders", async (req, res) => {
    const { description, remindAt } = req.body
    const id = await lembranca(description, remindAt)
    res.status(201).json({ _id: id })
})



app.listen(PORT, () => console.log("..."))