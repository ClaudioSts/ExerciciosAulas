const { ObjectId } = require("mongodb")
const { getMongoCollection } = require("./mongodb")

const DB_NAME = "mongo-sample-reminder"
const COLLECTION_NAME = "Reminders"

async function findAllReminders() {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    return await collection.find().toArray()
}

async function insertReminder(reminder) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const result = await collection.insertOne(reminder)
    return result.insertedId
}

async function getReminderByID(reminderId) {
    if (!ObjectId.isValid(reminderId)) return null
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const result = await collection.findOne({ _id: new ObjectId(reminderId) })
    return result
}

async function updateReminder(reminderId, description, remindAt) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const result = await collection.updateOne(
        { _id: new ObjectId(reminderId) },
        { $set: { description: description, remindAt: remindAt } }
    )
    return result
}


module.exports = {
    findAllReminders,
    insertReminder,
    getReminderByID,
    updateReminder
}