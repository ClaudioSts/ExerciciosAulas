export function TaskItem({concluido, texto, alternaConcluido, alteraTexto, removeTarefa}){
    return (
            <li onClick={alternaConcluido}>
                    {  
                        concluido 
                            ? <s>{texto}</s>
                            : <input
                                onClick={e => {
                                    e.stopPropagation()
                                    e.nativeEvent.stopImmediatePropagation()
                                }} 
                                value={texto}
                                onChange={(e) => alteraTexto(e.target.value)} 
                            />

                    }   
                    <button onClick={(e) => 
                    
                    })>
                        Remover
                    </button>
                </li>
            )
        

}