const arr = [
    {nome: 'Susana'},
    {nome: 'Renato'}
]

export function Lista() {
    return(
        <div>
            {arr.map((e) => <h3 key={e.nome}>{e.nome}</h3>)}
        </div>
    )
}