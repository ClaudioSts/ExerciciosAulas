import logo from './logo.svg';
import './App.css';

import Checkbox from "./Checkbox"
function App() {
  return (
    <div className="App">
      <Checkbox initialState={true}
      />
      <Checkbox initialState={false}
      />
    </div>
  );
}

export default App;
