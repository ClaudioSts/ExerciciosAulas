export function TaskCount({tasks}){
    return(
        <p>
            {tasks.filter({})}
        </p>

    )
    
}

export function TaskCountAlt({doneCount, totalCount}){
    return(
        <p>
            {doneCount} de {totalCount}
        </p>
    )

}