# Desafio de Frontend I

A interface deve ter **obrigatoriamente**:

- **Apresentação** do tempo em falta e/ou do tempo excedente;
- **Iniciar**; 
- **Pausar**;
- **Definição** do Tempo;
- **Reiniciar** (Repor)