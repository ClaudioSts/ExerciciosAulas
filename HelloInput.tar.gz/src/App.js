import logo from './logo.svg';
import './App.css';
import HelloInput from './HelloInput';

function App() {
  return (
    <div className="App">
      < HelloInput />
    </div>
  );
}

export default App;
